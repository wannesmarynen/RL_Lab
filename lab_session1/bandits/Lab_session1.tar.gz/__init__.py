"""
Module containing the code and plots from the first assignment
"""
